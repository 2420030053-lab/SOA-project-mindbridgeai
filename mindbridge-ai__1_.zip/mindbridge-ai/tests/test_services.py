"""
MindBridge AI - service tests

Run from the project root:
    pip install -r tests/requirements.txt
    pytest -v

Each service is imported directly from its own folder and exercised through
FastAPI's TestClient, so nothing needs to be running first and no network
call is made.
"""

import sys
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent.parent


def load(folder: str, module: str = "main"):
    """Import a module from a service folder that is not a Python package."""
    import importlib.util

    path = ROOT / folder / f"{module}.py"
    sys.path.insert(0, str(ROOT / folder))
    spec = importlib.util.spec_from_file_location(f"{folder}_{module}", path)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


crisis = TestClient(load("crisis-service").app)
wellness = TestClient(load("wellness-service").app)
accessibility = TestClient(load("accessibility-service").app)


# --- crisis-service -------------------------------------------------------

def test_calm_message_is_not_a_crisis():
    body = crisis.post("/analyze", json={"message": "I had a good day today."}).json()
    assert body["crisis_detected"] is False
    assert body["risk_level"] == "NONE"


def test_moderate_language_is_flagged_but_not_escalated():
    body = crisis.post("/analyze", json={"message": "I feel hopeless and trapped."}).json()
    assert body["risk_level"] == "MODERATE"
    assert body["crisis_detected"] is False
    assert body["matched_keywords"]


def test_acute_language_triggers_escalation_with_helplines():
    body = crisis.post("/analyze", json={"message": "I want to die."}).json()
    assert body["crisis_detected"] is True
    assert body["risk_level"] == "HIGH"
    assert body["helplines"]


# --- wellness-service -----------------------------------------------------

def test_wellness_detects_emotion_and_attaches_a_technique():
    body = wellness.post("/respond", json={"message": "I can't sleep at all."}).json()
    assert body["emotion_detected"] == "exhaustion"
    assert body["coping_technique"]["steps"]
    assert body["disclaimer"]


def test_wellness_uses_the_offline_pipeline_without_a_key():
    body = wellness.post("/respond", json={"message": "Just checking in."}).json()
    assert body["source"] == "deterministic-pipeline"
    assert body["emotion_detected"] == "general check-in"


def test_wellness_acknowledges_returning_users():
    history = [{"sender": "user", "text": "I felt anxious yesterday"}]
    body = wellness.post(
        "/respond", json={"message": "still anxious", "history": history}
    ).json()
    assert "earlier" in body["reply"]


# --- accessibility-service ------------------------------------------------

@pytest.mark.parametrize(
    "profile,expected",
    [
        ("visual", "read aloud automatically"),
        ("cognitive", "plain language"),
        ("motor", "quick-reply buttons offered"),
        ("none", "no adaptation needed"),
    ],
)
def test_each_profile_reports_its_adaptations(profile, expected):
    body = accessibility.post(
        "/adapt", json={"text": "One. Two. Three. Four. Five.", "profile": profile}
    ).json()
    assert expected in body["adaptations"]


def test_visual_profile_removes_sight_based_wording():
    body = accessibility.post(
        "/adapt", json={"text": "Look at the list and see what helps.", "profile": "visual"}
    ).json()
    assert body["speak_aloud"] is True
    assert "look at" not in body["adapted_text"].lower()


def test_cognitive_profile_caps_the_reply_at_three_sentences():
    body = accessibility.post(
        "/adapt", json={"text": "One. Two. Three. Four. Five.", "profile": "cognitive"}
    ).json()
    assert body["adapted_text"].count(".") <= 3
    assert body["reading_level"] == "plain"


def test_motor_profile_returns_quick_replies():
    body = accessibility.post(
        "/adapt", json={"text": "That sounds hard.", "profile": "motor"}
    ).json()
    assert len(body["quick_replies"]) >= 2


# --- orchestrator workflow ------------------------------------------------

def test_crisis_result_routes_away_from_the_wellness_crew():
    workflow = load("orchestrator-service", "workflow")
    assert workflow.route_after_crisis({"crisis_result": {"crisis_detected": True}}) == "crisis_response"
    assert workflow.route_after_crisis({"crisis_result": {"crisis_detected": False}}) == "wellness_coordination"


def test_graph_compiles_with_every_node():
    workflow = load("orchestrator-service", "workflow")
    graph = workflow.build_orchestrator_graph()
    nodes = graph.get_graph().nodes
    assert "crisis_check" in nodes
    assert "accessibility_adaptation" in nodes


# --- health ---------------------------------------------------------------

def test_every_service_reports_healthy():
    for client in (crisis, wellness, accessibility):
        assert client.get("/health").json()["status"] == "healthy"
