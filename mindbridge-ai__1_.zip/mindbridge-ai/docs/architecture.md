# Architecture notes

Written to match the objectives and project plan submitted in Review-1.

## 1. Why service-oriented, not monolithic

Review-1 identified monolithic architecture as a core limitation of existing
mental-health tools. This implementation avoids it by giving every capability
its own folder, its own dependencies, its own container and its own HTTP
contract:

* **Independent deployment** — restart `wellness-service` without dropping a
  single crisis assessment.
* **Independent scaling** — `docker compose up --scale wellness-service=3`
  runs three coaching replicas; the crisis screener is unaffected.
* **Fault isolation** — if `speech-service` is down, typed chat still works and
  the browser handles speech instead. If `crisis-service` is unreachable, the
  workflow records `risk_level=UNKNOWN` in the trace rather than silently
  treating the message as safe.
* **Replaceability** — `wellness-service` already has two interchangeable
  backends (deterministic pipeline, real CrewAI crew) behind one unchanged
  contract.

No service imports another service's code. The only coupling is the JSON shape
of four endpoints: `/analyze`, `/respond`, `/adapt`, `/transcribe`.

## 2. Multi-agent orchestration

| Agent / service | Role | Owns |
|---|---|---|
| crisis-service | Safety monitor | Risk classification only; it never speaks to the user |
| wellness-service | Coach crew | Context tagging, supportive reply, coping technique |
| accessibility-service | Adapter | Final shape of the text before delivery |
| orchestrator-service | Coordinator | Routing, escalation policy, session memory, trace |

The separation matters for safety. Because `crisis_check` runs before
`wellness_coordination` and the conditional edge can skip it entirely, a
high-risk message can never be answered with a generic wellness tip.

Escalation requires an explicit high-risk phrase. Several moderate words
together raise the score but do not trigger the bypass on their own — if the
crisis path fires on ordinary sadness, users learn to ignore it, and the
escalation stops meaning anything.

### LangGraph

`orchestrator-service/workflow.py` builds a real `StateGraph`:

```
load_conversation_context → crisis_check → [conditional]
        ├── crisis_detected → crisis_response ──────────────┐
        └── otherwise → wellness_coordination → accessibility_adaptation
                                                             ↓
                                              update_conversation_memory → END
```

`trace` is declared as `Annotated[List[...], operator.add]` so LangGraph
appends each node's entry instead of overwriting it, which is what lets the
whole route survive into the HTTP response.

### CrewAI

`wellness-service/agents.py` defines three role-based agents — Context,
Support and Coping Technique — run as a sequential `Crew`. It activates only
when `CREWAI_ENABLED=true` and `ANTHROPIC_API_KEY` are both present; otherwise
the identical three stages run as a deterministic in-process pipeline. Any
exception in the crew falls through to that pipeline, so a review demo never
fails because of a network hiccup or an expired key.

## 3. Accessibility layer

Accessibility is applied at two levels.

**Server side** (`accessibility-service`) — the reply itself is rewritten per
profile: sentence count is capped, sense-assuming vocabulary is swapped out
("look at" → "think about" for screen-reader users), quick replies are supplied
for motor profiles, and metadata (`speak_aloud`, `tts_recommended_rate_wpm`,
`aria_live_mode`, `font_scale`) is returned so any client knows how to present
it. The `aria_live_mode` flips to `assertive` for crisis replies so a screen
reader interrupts rather than queues.

**Client side** (`frontend/`) — semantic HTML with a skip link, a live region
for the chat, visible keyboard focus, `aria-pressed` on every toggle, a
high-contrast theme, two text sizes, reduced-motion support, and the Atkinson
Hyperlegible typeface, designed for readers with low vision.

Voice input prefers `speech-service` (Whisper) and falls back to the browser
Web Speech API when Whisper is not installed. The HTML/JS client stands in for
the Flutter client described in Review-1; both consume the same gateway API, so
the Flutter app can be added with no backend change.

## 4. Mapping to the Review-1 project plan

| Phase | Deliverable | Where it is in this repository |
|---|---|---|
| 1. Requirement analysis & SOA design | Agent roles, architecture, stack | This document; the four service contracts |
| 2. Core microservice development | FastAPI wellness + crisis services, Docker | `wellness-service/`, `crisis-service/`, per-service `Dockerfile` |
| 3. Multi-agent orchestration | CrewAI + LangGraph integration, inter-agent tests | `orchestrator-service/workflow.py`, `wellness-service/agents.py`, `tests/` |
| 4. Accessibility layer | Whisper pipeline, accessible UI | `speech-service/`, `accessibility-service/`, `frontend/` |
| 5. Testing & evaluation | Integration and compliance checks | `tests/test_services.py`, per-service `/health`, timing in every trace |
| 6. Deployment & documentation | Compose deployment, documentation | `docker-compose.yml` with healthchecks, `README.md`, this file |

## 5. Evaluation hooks already in place

* **Responsiveness** — every workflow node records its own latency and returns
  it in `trace`, so per-service timings can be collected straight from the API
  for the Review-2 benchmark.
* **Reliability of crisis detection** — the screener is a pure endpoint with no
  dependencies, so it can be run over a labelled message set to produce
  precision and recall without starting anything else.
* **Accessibility compliance** — `adaptations` is returned with every reply,
  giving a machine-readable record of what was changed for whom.

## 6. Known limitations, and what Review-2 should address

* Crisis detection is phrase-and-weight based. It misses paraphrase and
  sarcasm, and it is English-only. A fine-tuned classifier with a
  human-in-the-loop threshold is the natural next step.
* Session memory is a dictionary inside one process. It vanishes on restart and
  does not survive `--scale orchestrator-service=2`. A memory service backed by
  Redis is the cleanest way to demonstrate another independent service.
* No authentication between services. Real deployment needs service-to-service
  tokens and transport encryption, especially for health-adjacent data.
* Whisper is untested here against impaired speech; the SAP Challenge cited in
  the literature survey reports that fine-tuning is needed for that population.
