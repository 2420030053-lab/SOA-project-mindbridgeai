"""
MindBridge AI - speech-service
Independent microservice: accepts recorded audio, transcribes it with
OpenAI Whisper (runs locally, no external API call), and deletes the temp
file immediately afterwards. Powers voice input for users who cannot type
or navigate a keyboard easily.

Whisper and gTTS are optional. If they are not installed the endpoints
still return a valid response with engine="browser", and the frontend falls
back to the browser's own Web Speech API - so a review demo never blocks on
a model download.
"""

import base64
import io
import os
import tempfile

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="MindBridge AI - Speech Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_model = None


def get_model():
    """Load Whisper once, on first use. Returns None if it is not installed."""
    global _model
    if _model is None:
        try:
            import whisper
            _model = whisper.load_model(os.environ.get("WHISPER_MODEL", "base"))
        except Exception:
            return None
    return _model


class SpeakRequest(BaseModel):
    text: str
    language: str = "en"


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "speech-service",
        "whisper_installed": get_model() is not None,
    }


@app.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):
    contents = await file.read()
    if not contents or len(contents) > 25 * 1024 * 1024:
        raise HTTPException(status_code=413, detail="Audio must be non-empty and at most 25 MB.")

    model = get_model()
    if model is None:
        return {
            "text": "",
            "language": "en",
            "engine": "browser",
            "note": "Whisper is not installed. The frontend uses browser speech "
                    "recognition instead. Install it with: pip install openai-whisper",
        }

    suffix = os.path.splitext(file.filename or "audio.wav")[1] or ".wav"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        tmp.write(contents)
        tmp_path = tmp.name

    try:
        result = model.transcribe(tmp_path)
        return {
            "text": result.get("text", "").strip(),
            "language": result.get("language", "en"),
            "engine": "whisper",
        }
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


@app.post("/speak")
def speak(req: SpeakRequest):
    """Text to speech. Returns base64 MP3, or tells the client to use the browser."""
    try:
        from gtts import gTTS

        buffer = io.BytesIO()
        gTTS(text=req.text, lang=req.language).write_to_fp(buffer)
        return {
            "text": req.text,
            "engine": "gtts",
            "audio_base64": base64.b64encode(buffer.getvalue()).decode(),
        }
    except Exception:
        return {
            "text": req.text,
            "engine": "browser",
            "audio_base64": None,
            "note": "gTTS unavailable. The frontend reads the text aloud using the browser.",
        }
