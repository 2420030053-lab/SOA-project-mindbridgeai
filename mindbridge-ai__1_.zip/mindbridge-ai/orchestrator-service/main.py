"""
MindBridge AI - orchestrator-service
The single public gateway. The frontend only ever talks to this service; it
fans requests out to crisis-service, wellness-service and
accessibility-service through the LangGraph workflow in workflow.py, and
keeps in-memory session history per session_id.
"""

import os
import uuid
from typing import Dict, List, Optional

import httpx
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

from workflow import OrchestratorState, build_orchestrator_graph

app = FastAPI(title="MindBridge AI - Orchestrator Gateway", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

session_storage: Dict[str, List[Dict[str, str]]] = {}
graph_app = build_orchestrator_graph()

DOWNSTREAM = {
    "wellness-service": os.environ.get("WELLNESS_SERVICE_URL", "http://localhost:8001"),
    "crisis-service": os.environ.get("CRISIS_SERVICE_URL", "http://localhost:8002"),
    "accessibility-service": os.environ.get("ACCESSIBILITY_SERVICE_URL", "http://localhost:8003"),
    "speech-service": os.environ.get("SPEECH_SERVICE_URL", "http://localhost:8004"),
}


class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1)
    session_id: Optional[str] = None
    profile: str = "none"
    high_contrast: bool = False
    font_scale: float = Field(1.0, ge=0.8, le=2.0)


@app.get("/health")
def health_check():
    return {"status": "healthy", "service": "orchestrator-service (LangGraph)"}


@app.get("/services")
async def services_status():
    """Ping every downstream service so the frontend can show what is running."""
    report = []
    async with httpx.AsyncClient(timeout=2.0) as client:
        for name, base_url in DOWNSTREAM.items():
            entry = {"name": name, "url": base_url, "status": "down"}
            try:
                resp = await client.get(f"{base_url}/health")
                entry["status"] = "up" if resp.status_code == 200 else "down"
            except Exception:
                pass
            report.append(entry)
    return report


@app.get("/workflow")
def describe_workflow():
    """Expose the graph structure, useful for the review demo and for docs."""
    return {
        "entry": "load_conversation_context",
        "nodes": [
            "load_conversation_context", "crisis_check", "crisis_response",
            "wellness_coordination", "accessibility_adaptation", "update_conversation_memory",
        ],
        "conditional_edges": {
            "crisis_check": {
                "crisis_detected=true": "crisis_response",
                "crisis_detected=false": "wellness_coordination",
            }
        },
    }


@app.post("/chat")
async def chat_endpoint(request: ChatRequest):
    session_id = request.session_id or str(uuid.uuid4())
    session_storage.setdefault(session_id, [])

    state: OrchestratorState = {
        "session_id": session_id,
        "user_message": request.message,
        "profile": request.profile,
        "conversation_history": session_storage[session_id],
        "intent": None,
        "crisis_result": None,
        "wellness_result": None,
        "final_response": None,
        "trace": [],
        "high_contrast": request.high_contrast,
        "font_scale": request.font_scale,
    }

    result = await graph_app.ainvoke(state)
    session_storage[session_id] = result.get("conversation_history", [])

    payload = result.get("final_response", {})
    payload["session_id"] = session_id
    payload["trace"] = result.get("trace", [])
    return payload


@app.delete("/session/{session_id}")
def clear_session(session_id: str):
    """Forget one conversation. Sessions are in memory only and never persisted."""
    session_storage.pop(session_id, None)
    return {"status": "cleared", "session_id": session_id}
