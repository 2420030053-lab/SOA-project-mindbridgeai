"""
MindBridge AI - orchestrator-service workflow
A LangGraph StateGraph that coordinates the other four microservices:

  load_context -> crisis_check -> [route] -> crisis_response -> update_memory -> END
                                          -> wellness_coordination -> accessibility_adaptation -> update_memory -> END

Crisis screening always runs first and always wins: if it flags risk, the
graph short-circuits straight to a crisis response instead of routing
through the wellness crew, so a distressed user is never kept waiting on a
slower LLM pipeline. Every node appends to `trace`, which the frontend
renders so the service decomposition is visible rather than hidden.
"""

import os
import time
import operator
from typing import Annotated, Any, Dict, List, Optional, TypedDict

import httpx
from langgraph.graph import END, StateGraph

CRISIS_SERVICE_URL = os.environ.get("CRISIS_SERVICE_URL", "http://localhost:8002")
WELLNESS_SERVICE_URL = os.environ.get("WELLNESS_SERVICE_URL", "http://localhost:8001")
ACCESSIBILITY_SERVICE_URL = os.environ.get("ACCESSIBILITY_SERVICE_URL", "http://localhost:8003")


class OrchestratorState(TypedDict):
    session_id: str
    user_message: str
    profile: str
    conversation_history: List[Dict[str, str]]
    intent: Optional[str]
    crisis_result: Optional[Dict[str, Any]]
    wellness_result: Optional[Dict[str, Any]]
    final_response: Optional[Dict[str, Any]]
    # operator.add makes LangGraph append each node's trace entries instead
    # of overwriting them, so the full route survives to the response.
    trace: Annotated[List[Dict[str, Any]], operator.add]
    high_contrast: bool
    font_scale: float


def _step(service: str, action: str, detail: str, started: float) -> Dict[str, Any]:
    return {
        "service": service,
        "action": action,
        "detail": detail,
        "ms": int((time.perf_counter() - started) * 1000),
    }


# Node 1: load recent session context
async def load_conversation_context(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    history = state.get("conversation_history", [])
    return {
        "intent": "contextual_wellness",
        "conversation_history": history,
        "trace": [_step("orchestrator", "load_context", f"{len(history)} earlier turns", started)],
    }


# Node 2: crisis screening (highest priority, always runs first)
async def crisis_check(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.post(
                f"{CRISIS_SERVICE_URL}/analyze", json={"message": state["user_message"]}
            )
            resp.raise_for_status()
            result = resp.json()
    except Exception:
        # Fail safe, not fail open: if the screener is unreachable, say so in
        # the trace rather than silently treating the message as safe.
        result = {"crisis_detected": False, "risk_level": "UNKNOWN", "score": 0,
                  "matched_keywords": [], "advice": "", "helplines": []}

    return {
        "crisis_result": result,
        "trace": [_step("crisis-service", "analyze",
                        f"risk={result['risk_level']} score={result.get('score', 0)}", started)],
    }


def route_after_crisis(state: OrchestratorState) -> str:
    if state.get("crisis_result", {}).get("crisis_detected", False):
        return "crisis_response"
    return "wellness_coordination"


# Node 3A: crisis response - bypasses the wellness crew entirely
async def crisis_response(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    crisis = state.get("crisis_result", {})
    return {
        "final_response": {
            "status": "success",
            "type": "crisis",
            "crisis_detected": True,
            "risk_level": crisis.get("risk_level", "HIGH"),
            "reply": crisis.get("advice", ""),
            "helplines": crisis.get("helplines", []),
            "emotion_detected": "acute distress",
            "coping_technique": {
                "title": "5-4-3-2-1 grounding",
                "steps": ["5 things you can see", "4 things you can touch",
                          "3 things you can hear", "2 things you can smell", "1 slow breath"],
                "duration": "2 min",
            },
        },
        "trace": [_step("orchestrator", "escalate",
                        "wellness crew bypassed, helplines returned", started)],
    }


# Node 3B: wellness crew coordination
async def wellness_coordination(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    async with httpx.AsyncClient(timeout=60.0) as client:
        resp = await client.post(
            f"{WELLNESS_SERVICE_URL}/respond",
            json={
                "message": state["user_message"],
                "history": state.get("conversation_history", []),
                "intent": state.get("intent"),
            },
        )
        resp.raise_for_status()
        result = resp.json()

    return {
        "wellness_result": result,
        "trace": [_step("wellness-service", "respond",
                        f"emotion={result.get('emotion_detected')} "
                        f"source={result.get('source')}", started)],
    }


# Node 4: accessibility adaptation
async def accessibility_adaptation(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    wellness = state.get("wellness_result", {})

    async with httpx.AsyncClient(timeout=10.0) as client:
        resp = await client.post(
            f"{ACCESSIBILITY_SERVICE_URL}/adapt",
            json={
                "text": wellness.get("reply", ""),
                "profile": state.get("profile", "none"),
                "high_contrast": state.get("high_contrast", False),
                "font_scale": state.get("font_scale", 1.0),
                "screen_reader": state.get("profile") == "visual",
            },
        )
        resp.raise_for_status()
        adapted = resp.json()

    return {
        "final_response": {
            **wellness,
            "status": "success",
            "type": "wellness",
            "crisis_detected": False,
            "risk_level": state.get("crisis_result", {}).get("risk_level", "NONE"),
            "reply": adapted.get("adapted_text", wellness.get("reply", "")),
            "accessibility": adapted,
            "helplines": [],
        },
        "trace": [_step("accessibility-service", "adapt",
                        f"profile={state.get('profile', 'none')} "
                        f"changes={len(adapted.get('adaptations', []))}", started)],
    }


# Node 5: append this turn to session memory
async def update_conversation_memory(state: OrchestratorState) -> Dict[str, Any]:
    started = time.perf_counter()
    history = list(state.get("conversation_history", []))
    history.append({"sender": "user", "text": state["user_message"]})
    if state.get("final_response"):
        history.append({"sender": "bot", "text": state["final_response"].get("reply", "")})

    return {
        "conversation_history": history,
        "trace": [_step("orchestrator", "update_memory", f"{len(history)} turns stored", started)],
    }


def build_orchestrator_graph():
    wf = StateGraph(OrchestratorState)
    wf.add_node("load_conversation_context", load_conversation_context)
    wf.add_node("crisis_check", crisis_check)
    wf.add_node("crisis_response", crisis_response)
    wf.add_node("wellness_coordination", wellness_coordination)
    wf.add_node("accessibility_adaptation", accessibility_adaptation)
    wf.add_node("update_conversation_memory", update_conversation_memory)

    wf.set_entry_point("load_conversation_context")
    wf.add_edge("load_conversation_context", "crisis_check")
    wf.add_conditional_edges(
        "crisis_check",
        route_after_crisis,
        {"crisis_response": "crisis_response", "wellness_coordination": "wellness_coordination"},
    )
    wf.add_edge("crisis_response", "update_conversation_memory")
    wf.add_edge("wellness_coordination", "accessibility_adaptation")
    wf.add_edge("accessibility_adaptation", "update_conversation_memory")
    wf.add_edge("update_conversation_memory", END)
    return wf.compile()
