"""
Start all five MindBridge AI microservices plus the frontend, in one command:

    python run_all.py

Then open http://127.0.0.1:8080
Press Ctrl+C once to stop everything.

Each service still runs as its own independent process on its own port -
this script is only a convenience for local development and review demos.
For deployment use docker-compose.yml instead.
"""

import subprocess
import sys
import time
import webbrowser
from pathlib import Path

ROOT = Path(__file__).parent

SERVICES = [
    ("crisis-service", 8002),
    ("wellness-service", 8001),
    ("accessibility-service", 8003),
    ("speech-service", 8004),
    ("orchestrator-service", 8000),
]

FRONTEND_PORT = 8080


def main() -> None:
    processes = []
    print("Starting MindBridge AI...\n")

    for folder, port in SERVICES:
        command = [
            sys.executable, "-m", "uvicorn", "main:app",
            "--host", "127.0.0.1", "--port", str(port), "--log-level", "warning",
        ]
        processes.append((folder, subprocess.Popen(command, cwd=ROOT / folder)))
        print(f"  {folder:24} http://127.0.0.1:{port}   (docs at /docs)")

    frontend = subprocess.Popen(
        [sys.executable, "-m", "http.server", str(FRONTEND_PORT), "--bind", "127.0.0.1"],
        cwd=ROOT / "frontend",
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    processes.append(("frontend", frontend))
    print(f"  {'frontend':24} http://127.0.0.1:{FRONTEND_PORT}")

    print(f"\nOpen the app:     http://127.0.0.1:{FRONTEND_PORT}")
    print("Stop everything:  Ctrl+C\n")

    time.sleep(3)
    try:
        webbrowser.open(f"http://127.0.0.1:{FRONTEND_PORT}")
    except Exception:
        pass

    try:
        while True:
            time.sleep(1)
            for name, process in processes:
                if process.poll() is not None:
                    print(f"[warning] {name} stopped unexpectedly.")
                    return
    except KeyboardInterrupt:
        print("\nShutting down...")
    finally:
        for _, process in processes:
            process.terminate()
        for _, process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
        print("All services stopped.")


if __name__ == "__main__":
    main()
