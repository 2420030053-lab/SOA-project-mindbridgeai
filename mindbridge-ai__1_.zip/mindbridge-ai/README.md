# MindBridge AI — Microservices Prototype

**Intelligent Multi-Agent Mental Wellness and Accessibility Platform for Disabled Individuals**

Course: SOA Programming and Microservices (24SDCS03) · A.Y. 2026–2027
Department of CSE, KLH Bowrampet Campus

| University ID | Name |
|---|---|
| 2420030053 | Kakunuri Yasaswi |
| 2420030424 | Muduganti Sahithi Reddy |

Guide: **Dr. Srikanth Cherukuvada**, Assistant Professor, Department of CSE

---

## Architecture

```
frontend (browser)
      │
      ▼
orchestrator-service  :8000   LangGraph StateGraph gateway + session memory
      │
      ├──► crisis-service         :8002   weighted-phrase crisis screening (always runs first)
      ├──► wellness-service       :8001   CrewAI-style 3-agent crew (context → support → technique)
      ├──► accessibility-service  :8003   profile-based adaptation + ARIA/TTS metadata
      └──► speech-service         :8004   Whisper speech-to-text (called directly by the frontend)
```

The orchestrator's LangGraph workflow (`orchestrator-service/workflow.py`)
always screens for crisis risk first. A high-risk message routes straight to a
crisis response, bypassing the slower wellness crew entirely — that is the
load-bearing design decision from the literature review: coordination overhead
between wellness, crisis and accessibility is exactly what increases response
latency for a distressed user, so crisis detection short-circuits everything
else.

Every node appends to a `trace` array that the frontend renders, so the service
decomposition is visible on screen during the review instead of hidden inside
the backend.

## Run without Docker (VS Code, for review day)

```bash
python -m venv .venv
.venv\Scripts\activate          # macOS / Linux: source .venv/bin/activate

pip install -r orchestrator-service/requirements.txt
pip install -r wellness-service/requirements.txt
pip install -r crisis-service/requirements.txt
pip install -r accessibility-service/requirements.txt
pip install -r speech-service/requirements.txt

python run_all.py
```

`run_all.py` starts all five services plus a static server for the frontend and
opens **http://127.0.0.1:8080**. Press `Ctrl+C` once to stop everything.

To run them separately instead — the way the services are actually meant to be
deployed — open five terminals:

```bash
cd crisis-service        && uvicorn main:app --port 8002
cd wellness-service      && uvicorn main:app --port 8001
cd accessibility-service && uvicorn main:app --port 8003
cd speech-service        && uvicorn main:app --port 8004
cd orchestrator-service  && uvicorn main:app --port 8000
```

Then open `frontend/index.html` in the browser.

## Run with Docker Compose

```bash
copy .env.example .env      # macOS / Linux: cp .env.example .env
docker compose up --build
```

Gateway: `http://localhost:8000` · Docs: `http://localhost:8000/docs`
Open `frontend/index.html` for the UI.

## What to try in the app

1. `I can't sleep and I feel overwhelmed at college` → wellness path, emotion
   tagged as exhaustion, wind-down technique attached.
2. Switch **I use the app with** to *Plain, simple language* and send it again →
   the same reply comes back capped at three sentences, and the trace shows
   `accessibility-service` doing the work.
3. Switch to *Limited hand movement* → the reply arrives with quick-reply
   buttons so no typing is needed.
4. `I feel hopeless and trapped` → MODERATE risk, still routed to the wellness
   crew.
5. `I want to die` → HIGH risk. The trace shows the wellness crew was **never
   called**, and helplines appear in an assertive-live-region banner.
6. Press **Speak** and talk instead of typing.
7. Press **High contrast** and **Larger text**.

## Run the tests

```bash
pip install -r tests/requirements.txt
pytest -v
```

Sixteen tests cover the three crisis bands, emotion tagging, session-aware
replies, every accessibility profile, and the LangGraph routing function.
Nothing needs to be running first.

## No API key needed to demo

Every service works fully offline:

* **wellness-service** runs a deterministic three-stage pipeline (context
  tagging → support draft → coping technique) unless `CREWAI_ENABLED=true` and
  `ANTHROPIC_API_KEY` are both set, in which case it runs a real CrewAI crew
  with Claude as the LLM. CrewAI is a large install, so it lives in
  `wellness-service/requirements-crewai.txt` rather than the default
  requirements.
  Both backends are personalized, not templated: the context stage also tags
  the specific *topic* (work, school, family, relationship, health, money) and
  the *intensity* of the message, the support draft names that topic directly
  and rotates its phrasing across turns instead of repeating a fixed string,
  and the technique stage tracks what has already been suggested in the
  session so a returning user is not handed the same exercise twice in a row.
* **crisis-service** is phrase-based and needs no key at all.
* **speech-service** runs Whisper locally when
  `speech-service/requirements-whisper.txt` is installed (needs `ffmpeg`, and
  downloads the `base` model on first use — no external API call). Without it
  the frontend falls back to the browser's Web Speech API, so voice input and
  read-aloud still work.

## API examples

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"I am overwhelmed about tomorrow'\''s exam","profile":"cognitive"}'

curl -X POST http://localhost:8002/analyze \
  -H "Content-Type: application/json" -d '{"message":"I feel hopeless"}'

curl -X POST http://localhost:8004/transcribe -F "file=@recording.webm"
```

Every service has its own Swagger UI at `/docs`, so each one can be
demonstrated on its own — that independence is the point of the SOA
decomposition.

## Project layout

```
mindbridge-ai/
├── run_all.py                  start all five services + frontend
├── docker-compose.yml          five containers with healthchecks
├── orchestrator-service/       main.py, workflow.py (LangGraph), Dockerfile
├── crisis-service/             main.py, Dockerfile
├── wellness-service/           main.py, agents.py (CrewAI), Dockerfile
├── accessibility-service/      main.py, Dockerfile
├── speech-service/             main.py, Dockerfile
├── frontend/                   index.html, style.css, script.js
├── tests/                      pytest suite
└── docs/architecture.md        design notes mapped to the Review-1 plan
```

Each service folder is fully self-contained: its own `requirements.txt`, its own
`Dockerfile`, no shared Python package. Any one of them could be rewritten in
another language tomorrow as long as it honours the same JSON contract.

## Push to GitHub

```bash
git init
git add .
git commit -m "MindBridge AI: multi-agent wellness and accessibility microservices"
git branch -M main
git remote add origin https://github.com/<your-username>/mindbridge-ai.git
git push -u origin main
```

`.gitignore` already excludes `.venv/`, `.env` and caches.

---

MindBridge AI provides supportive information and emergency routing; it does not
replace medical or mental health professionals. In an immediate emergency,
contact local emergency services and a trusted person nearby.
