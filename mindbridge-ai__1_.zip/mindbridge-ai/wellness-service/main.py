"""
MindBridge AI - wellness-service
Independent microservice hosting the CrewAI-coordinated wellness crew
(context agent -> support agent -> coping-technique agent). Called only by
the orchestrator-service, never directly by the client.
"""

from typing import Dict, List, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agents import USE_CREWAI, build_contextual_wellness_crew

app = FastAPI(title="MindBridge AI - Wellness Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class RespondRequest(BaseModel):
    message: str
    history: Optional[List[Dict[str, str]]] = []
    intent: Optional[str] = None


@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "wellness-service",
        "mode": "crewai" if USE_CREWAI else "deterministic-pipeline",
    }


@app.post("/respond")
def respond(req: RespondRequest):
    return build_contextual_wellness_crew(req.message, req.history or [], req.intent)
