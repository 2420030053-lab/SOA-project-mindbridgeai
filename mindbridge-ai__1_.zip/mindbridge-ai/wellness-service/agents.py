"""
MindBridge AI - wellness-service agents
Three role-based agents coordinated sequentially, mirroring a CrewAI crew:
  1. Context Agent   - reads the message plus recent history, tags emotion,
                        topic, and intensity so the reply is grounded in what
                        the user actually said, not just a category label
  2. Support Agent   - drafts an empathetic, non-diagnostic reply that
                        references that specific context and varies its
                        phrasing turn over turn instead of repeating itself
  3. Technique Agent - attaches one concrete coping technique, rotating
                        between options for the same emotion so a returning
                        user is not handed the identical exercise every time

If CREWAI_ENABLED and ANTHROPIC_API_KEY are both set, the crew runs on real
CrewAI Agents/Tasks with Claude as the LLM, with the full conversation
history threaded through every task so the model can personalize and avoid
repeating itself. Otherwise the same three stages run as a deterministic
in-process pipeline, so the service is fully functional offline - no review
demo should depend on an API key working on the day.
"""

import json
import os
import re
from typing import Any, Dict, List, Optional

USE_CREWAI = (
    os.environ.get("CREWAI_ENABLED", "false").lower() == "true"
    and bool(os.environ.get("ANTHROPIC_API_KEY"))
)

DISCLAIMER = "MindBridge AI is not a replacement for medical or mental health professionals."

# Stage 1 vocabulary: message -> emotion tag.
EMOTIONS = {
    "anxiety": ["anxious", "anxiety", "nervous", "worried", "panic", "racing",
                "overwhelmed", "stressed", "on edge", "can't relax", "cannot relax"],
    "low mood": ["sad", "down", "depressed", "low", "empty", "numb", "hopeless"],
    "frustration": ["angry", "frustrated", "mad", "irritated", "fed up", "sick of"],
    "exhaustion": ["tired", "exhausted", "burnt out", "burned out", "can't sleep", "cannot sleep",
                   "no energy", "drained"],
    "loneliness": ["lonely", "alone", "isolated", "nobody", "no one to talk to"],
    "self-criticism": ["useless", "failure", "stupid", "worthless", "bad at", "not good enough",
                        "i'm a mess", "i am a mess"],
}

# Stage 1 vocabulary: message -> topic, so the reply can name what is
# actually going on instead of only naming the emotion.
TOPICS: Dict[str, List[str]] = {
    "work": ["work", "job", "boss", "deadline", "workload", "coworker", "colleague",
             "manager", "office", "career", "shift", "meeting"],
    "school": ["exam", "exams", "test", "school", "college", "university", "class",
               "studying", "study", "assignment", "grades", "homework", "semester"],
    "family": ["family", "parents", "mom", "mum", "mother", "dad", "father",
               "sister", "brother", "in-laws"],
    "relationship": ["relationship", "boyfriend", "girlfriend", "partner", "breakup",
                      "broke up", "dating", "divorce", "husband", "wife"],
    "health": ["health", "sick", "pain", "diagnosis", "doctor", "illness", "symptoms"],
    "money": ["money", "rent", "bills", "debt", "financial", "afford", "broke", "paycheck"],
    "future": ["future", "no direction", "don't know what to do", "what's next",
               "uncertain about"],
}

TOPIC_PHRASES: Dict[str, str] = {
    "work": "everything going on at work",
    "school": "the pressure around school",
    "family": "what's happening with your family",
    "relationship": "what's going on in your relationship",
    "health": "what you're dealing with health-wise",
    "money": "the money stress you mentioned",
    "future": "not knowing what's next",
}

# Words/phrases that signal the message is describing something intense
# rather than a mild, passing feeling.
INTENSIFIERS = [
    "really", "so ", "extremely", "very ", "completely", "totally", "constantly",
    "every day", "all the time", "can't take", "cannot take", "can't handle",
    "cannot handle", "so much", "keeps happening", "nonstop", "non-stop", "again and again",
]

# Stage 2 vocabulary: emotion -> a few opening lines to rotate through, so a
# returning user is met with a fresh sentence instead of the same one.
SUPPORT_VARIANTS: Dict[str, List[str]] = {
    "anxiety": [
        "That sounds like a lot to carry right now, and it makes sense that your body is reacting.",
        "Racing thoughts like that are exhausting on their own, even before anything else piles on.",
        "It makes sense your mind is on high alert when this much is unresolved.",
    ],
    "low mood": [
        "Feeling flat like this is heavy, and it is not something you chose.",
        "That empty, weighed-down feeling is real, even on the days it is hard to explain.",
        "It sounds like the color has gone out of things a bit right now.",
    ],
    "frustration": [
        "Frustration usually means something mattered to you and did not go the way it should have.",
        "That kind of frustration builds when you have tried and it still is not landing.",
        "It makes sense you are fed up - this has clearly been grating on you.",
    ],
    "exhaustion": [
        "Running on empty makes everything else feel harder than it really is.",
        "That kind of tired is not solved by one good night's sleep, and it is wearing on you.",
        "It sounds like you have been pushing through on very little for a while now.",
    ],
    "loneliness": [
        "Loneliness is painful, and saying it out loud takes something.",
        "Feeling unseen like that is one of the harder things to sit with.",
        "It takes courage to name that you are feeling alone in this.",
    ],
    "self-criticism": [
        "You are being pretty harsh with yourself in that sentence.",
        "That inner voice is being a lot tougher on you than a friend would be.",
        "Notice how much weight you are putting on yourself there.",
    ],
    "general check-in": [
        "Thank you for telling me that. You do not have to have it sorted out to talk here.",
        "I'm glad you checked in - this is a good place to think out loud, no pressure to have answers.",
    ],
}

INTENSITY_LINE = "The way you're describing it, this isn't a small thing today - it sounds like it's been building."

# Stage 3 vocabulary: emotion -> a rotation of coping techniques, so a
# returning user is not handed the identical exercise every time.
TECHNIQUES: Dict[str, List[Dict[str, Any]]] = {
    "anxiety": [
        {
            "title": "5-4-3-2-1 grounding",
            "steps": ["5 things you can see", "4 things you can touch", "3 things you can hear",
                      "2 things you can smell", "1 slow breath"],
            "duration": "2 min",
        },
        {
            "title": "Box breathing",
            "steps": ["Breathe in for 4 counts", "Hold for 4 counts",
                      "Breathe out for 4 counts", "Hold for 4 counts", "Repeat 4 times"],
            "duration": "2 min",
        },
    ],
    "low mood": [
        {
            "title": "One tiny task",
            "steps": ["Pick something that takes under 2 minutes", "Do only that one thing",
                       "Notice you finished it, nothing more"],
            "duration": "2 min",
        },
        {
            "title": "Name three",
            "steps": ["Name one thing you can see", "Name one thing that helped today, however small",
                       "Say it out loud or write it down"],
            "duration": "2 min",
        },
    ],
    "frustration": [
        {
            "title": "Release and reset",
            "steps": ["Clench your fists for 5 seconds", "Release and shake out your hands",
                       "Name the actual thing that is frustrating you in one sentence"],
            "duration": "1 min",
        },
        {
            "title": "Step away",
            "steps": ["Physically leave the situation for 2 minutes if you can",
                       "Walk or stretch", "Come back once your breathing has slowed"],
            "duration": "5 min",
        },
    ],
    "exhaustion": [
        {
            "title": "Wind-down routine",
            "steps": ["Dim the lights 30 minutes before bed", "Put the phone in another room",
                      "Write tomorrow's first task on paper"],
            "duration": "30 min",
        },
        {
            "title": "Micro-rest",
            "steps": ["Sit or lie down somewhere quiet", "Close your eyes for 5 minutes",
                       "No phone, no to-do list, just stillness"],
            "duration": "5 min",
        },
    ],
    "loneliness": [
        {
            "title": "One small contact",
            "steps": ["Pick one person", "Send one short message", "No explanation needed"],
            "duration": "2 min",
        },
        {
            "title": "Say it out loud",
            "steps": ["Name the feeling out loud, even alone in a room",
                       "Write one sentence about what you need right now",
                       "Keep it somewhere you'll see it later"],
            "duration": "2 min",
        },
    ],
    "self-criticism": [
        {
            "title": "Friend reframe",
            "steps": ["Describe the situation as if to a friend you respect",
                      "Keep the facts, drop the verdict", "Read it back once"],
            "duration": "5 min",
        },
        {
            "title": "Evidence check",
            "steps": ["Write the harsh thought down exactly as it came",
                       "List one piece of evidence against it",
                       "Rewrite it as something you'd say to someone you cared about"],
            "duration": "5 min",
        },
    ],
    "default": [
        {
            "title": "Grounding breath",
            "steps": ["Breathe in for 4 counts", "Hold for 4 counts", "Breathe out for 6 counts",
                      "Repeat 3 times"],
            "duration": "1 min",
        },
    ],
}

_ALL_TECHNIQUE_TITLES = {t["title"] for options in TECHNIQUES.values() for t in options}


def _detect_emotion(message: str, intent: Optional[str]) -> str:
    lower = message.lower()
    for emotion, words in EMOTIONS.items():
        if any(word in lower for word in words):
            return emotion
    return intent or "general check-in"


def _detect_topic(message: str) -> Optional[str]:
    lower = message.lower()
    for topic, words in TOPICS.items():
        if any(word in lower for word in words):
            return topic
    return None


def _detect_intensity(message: str) -> str:
    lower = message.lower()
    hits = sum(1 for phrase in INTENSIFIERS if phrase in lower)
    hits += lower.count("!!")
    caps_words = [w for w in re.findall(r"[A-Za-z']+", message) if len(w) >= 3 and w.isupper()]
    hits += len(caps_words)
    if hits >= 2:
        return "high"
    if hits == 1:
        return "moderate"
    return "mild"


def _previously_used_techniques(history: List[Dict[str, str]]) -> set:
    """Scan the bot's earlier turns for technique titles already offered,
    so the same exercise is not repeated back to back."""
    used = set()
    for turn in history:
        if turn.get("sender") == "bot":
            text = turn.get("text", "")
            for title in _ALL_TECHNIQUE_TITLES:
                if title in text:
                    used.add(title)
    return used


def _pick_technique(emotion: str, history: List[Dict[str, str]]) -> Dict[str, Any]:
    options = TECHNIQUES.get(emotion, TECHNIQUES["default"])
    used = _previously_used_techniques(history)
    for option in options:
        if option["title"] not in used:
            return option
    return options[0]


def _build_question(topic: Optional[str], returning: bool) -> str:
    if returning:
        if topic:
            return f"Is it still mostly about {TOPIC_PHRASES[topic]}, or has something shifted?"
        return "What's changed since then, if anything?"
    if topic:
        return f"Tell me a bit more about {TOPIC_PHRASES[topic]}."
    return "Tell me a little more about what is weighing on you most."


def _fallback_crew(message: str, history: List[Dict[str, str]], intent: Optional[str]) -> Dict[str, Any]:
    """Deterministic three-stage pipeline used when CrewAI is not configured.
    Personalizes on the topic actually mentioned, the apparent intensity of
    the message, and rotates phrasing/technique across turns rather than
    returning the same fixed string for every message in a category."""
    # Stage 1 - context and personalization
    emotion = _detect_emotion(message, intent)
    topic = _detect_topic(message)
    intensity = _detect_intensity(message)
    returning = len(history) > 0
    turn_index = len(history) // 2  # number of prior user/bot exchanges

    # Stage 2 - wellness support draft
    variants = SUPPORT_VARIANTS.get(emotion, SUPPORT_VARIANTS["general check-in"])
    opening = variants[turn_index % len(variants)]

    parts = [opening]

    if topic:
        parts.append(f"It sounds like {TOPIC_PHRASES[topic]} is a big part of what's weighing on you right now.")

    if intensity == "high":
        parts.append(INTENSITY_LINE)

    if returning:
        parts.append("You mentioned something similar earlier, so let's stay with it.")

    parts.append(_build_question(topic, returning))
    parts.append("Would you like to try something small that often helps?")

    reply = "\n\n".join(parts)

    # Stage 3 - coping technique, rotated so it doesn't repeat
    technique = _pick_technique(emotion, history)

    return {
        "reply": reply,
        "emotion_detected": emotion,
        "topic_detected": topic,
        "intensity": intensity,
        "coping_technique": technique,
        "disclaimer": DISCLAIMER,
        "source": "deterministic-pipeline",
    }


def _crewai_crew(message: str, history: List[Dict[str, str]], intent: Optional[str]) -> Dict[str, Any]:
    from crewai import LLM, Agent, Crew, Task

    llm = LLM(model="anthropic/claude-sonnet-4-5", api_key=os.environ["ANTHROPIC_API_KEY"])

    context_agent = Agent(
        role="Context and Personalization Agent",
        goal="Understand the current message in the context of the recent conversation, "
             "and identify the concrete topic and intensity behind the feeling.",
        backstory="A careful analyst who identifies emotion, topic, intensity, and the "
                   "kind of help being asked for - never generic labels alone.",
        llm=llm, verbose=False, allow_delegation=False,
    )
    support_agent = Agent(
        role="Wellness Support Agent",
        goal="Give supportive, personalized, non-diagnostic guidance for this exact situation, "
             "written so it could only be a reply to this message, not a template.",
        backstory="An empathetic psychological first-aid coach skilled at active listening, "
                   "who never repeats a phrase or opening line already used earlier in the chat.",
        llm=llm, verbose=False, allow_delegation=False,
    )
    technique_agent = Agent(
        role="Coping Technique Agent",
        goal="Attach one concrete, short coping technique that fits the situation and has not "
             "already been suggested earlier in this conversation.",
        backstory="A practical wellbeing coach who prefers small actionable steps over advice, "
                   "and keeps track of what has already been offered so it stays fresh.",
        llm=llm, verbose=False, allow_delegation=False,
    )

    history_json = json.dumps(history[-8:], ensure_ascii=True)

    context_task = Task(
        description=(
            f"Analyze this user message: {message}\n"
            f"Inferred intent: {intent or 'unknown'}\nRecent history: {history_json}\n"
            "Identify: the specific situation/topic in the user's own terms (e.g. work, "
            "an exam, a relationship, family, health, money), the emotion, how intense the "
            "message sounds, and the kind of help requested. Do not generalize away the "
            "concrete details the user gave you."
        ),
        expected_output="A concise situation, topic, intensity, and emotion analysis.",
        agent=context_agent,
    )
    support_task = Task(
        description=(
            f"Recent history for tone/continuity (do not repeat earlier phrasing from it "
            f"verbatim): {history_json}\n"
            "Using the analysis, write a warm, specific, non-diagnostic reply in at most "
            "four short sentences. Reference the actual topic and details from the user's "
            "message rather than generic encouragement. If the history shows this user has "
            "raised something similar before, acknowledge that continuity briefly. Never "
            "diagnose and never claim to be a therapist."
        ),
        expected_output="A personalized supportive reply, distinct from any earlier reply in the history.",
        agent=support_agent,
        context=[context_task],
    )
    technique_task = Task(
        description=(
            f"Recent history, so you can avoid repeating a technique already offered in it: "
            f"{history_json}\n"
            "Add one short coping technique with 3 to 5 steps, chosen to fit this user's "
            "specific situation and not already suggested earlier in the history. Return "
            "ONLY valid JSON with keys: reply, emotion_detected, topic_detected, "
            "coping_technique (an object with title, steps, duration)."
        ),
        expected_output="Valid JSON with reply, emotion_detected, topic_detected, coping_technique.",
        agent=technique_agent,
        context=[support_task],
    )

    crew = Crew(
        agents=[context_agent, support_agent, technique_agent],
        tasks=[context_task, support_task, technique_task],
        process="sequential",
        verbose=False,
    )
    raw = getattr(crew.kickoff(), "raw", "").strip()
    cleaned = re.sub(r"```json|```", "", raw).strip()

    try:
        response = json.loads(cleaned)
    except json.JSONDecodeError:
        response = {
            "reply": raw,
            "emotion_detected": _detect_emotion(message, intent),
            "topic_detected": _detect_topic(message),
            "coping_technique": TECHNIQUES["default"][0],
        }

    response.setdefault("disclaimer", DISCLAIMER)
    response["source"] = "crewai"
    return response


def build_contextual_wellness_crew(
    message: str,
    conversation_history: List[Dict[str, str]],
    inferred_intent: Optional[str] = None,
) -> Dict[str, Any]:
    """Entry point used by main.py. Falls back to the offline pipeline on any error."""
    if USE_CREWAI:
        try:
            return _crewai_crew(message, conversation_history, inferred_intent)
        except Exception:
            pass
    return _fallback_crew(message, conversation_history, inferred_intent)
