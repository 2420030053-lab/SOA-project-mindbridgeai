"""
MindBridge AI - crisis-service
Independent microservice: highest-priority screening for acute distress.
Runs standalone so it can be scaled, monitored, or swapped for a trained
classifier without touching any other service. It only classifies - it
never replies to the user, so escalation policy stays with the
orchestrator.
"""

import re

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="MindBridge AI - Crisis Detection Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Weighted phrases. Weight reflects how strongly the phrase indicates acute risk.
HIGH_RISK = {
    "want to die": 1.0,
    "end my life": 1.0,
    "kill myself": 1.0,
    "better off dead": 1.0,
    "no reason to live": 0.9,
    "cannot go on": 0.7,
    "can't go on": 0.7,
    "give up on everything": 0.7,
}

MODERATE_RISK = {
    "hopeless": 0.5,
    "worthless": 0.5,
    "nobody cares": 0.6,
    "nobody would care": 0.6,
    "trapped": 0.45,
    "completely alone": 0.45,
    "panic attack": 0.4,
    "can't cope": 0.5,
    "cannot cope": 0.5,
    "can't stop crying": 0.4,
}

LOW_RISK = {
    "stressed": 0.15,
    "anxious": 0.2,
    "overwhelmed": 0.25,
    "exhausted": 0.15,
    "can't sleep": 0.2,
    "cannot sleep": 0.2,
    "lonely": 0.25,
}

HELPLINES = [
    "India - Tele-MANAS: 14416 (free, 24x7, multilingual)",
    "India - AASRA: +91 98204 66726",
    "US - 988 Suicide & Crisis Lifeline: call or text 988",
    "Anywhere - your local emergency number",
]

CRISIS_ADVICE = (
    "I'm really glad you told me, and I don't want you to sit with this alone. "
    "What you're describing deserves support from a real person right now. "
    "Please contact one of the helplines below, or reach someone you trust and "
    "stay with them."
)


class AnalyzeRequest(BaseModel):
    message: str


@app.get("/health")
def health():
    return {"status": "healthy", "service": "crisis-service"}


@app.post("/analyze")
def analyze(req: AnalyzeRequest):
    text = re.sub(r"[^\w\s'-]", " ", req.message.lower())
    score = 0.0
    matched = []
    high_hit = False

    for table, band in [(HIGH_RISK, "HIGH"), (MODERATE_RISK, "MODERATE"), (LOW_RISK, "LOW")]:
        for phrase, weight in table.items():
            if phrase in text:
                score += weight
                matched.append(f"{band}: {phrase}")
                if band == "HIGH":
                    high_hit = True

    score = round(min(score, 1.0), 2)

    # Escalation requires an explicit high-risk phrase. Several moderate words
    # together raise the score but must not, on their own, trigger the crisis
    # bypass - that keeps false escalations rare enough to stay meaningful.
    if high_hit:
        return {
            "crisis_detected": True,
            "risk_level": "HIGH",
            "score": score,
            "matched_keywords": matched,
            "advice": CRISIS_ADVICE,
            "helplines": HELPLINES,
        }

    if score >= 0.35:
        return {
            "crisis_detected": False,
            "risk_level": "MODERATE",
            "score": score,
            "matched_keywords": matched,
            "advice": "",
            "helplines": [],
        }

    return {
        "crisis_detected": False,
        "risk_level": "NONE",
        "score": score,
        "matched_keywords": matched,
        "advice": "",
        "helplines": [],
    }
