/* MindBridge AI frontend.
   Talks to the orchestrator gateway on :8000 for chat, and to
   speech-service on :8004 for Whisper transcription. It never calls the
   wellness, crisis or accessibility services directly. */

const API_BASE = "http://localhost:8000";
const SPEECH_BASE = "http://localhost:8004";

let sessionId = null;
let readAloud = false;
let highContrast = false;
let fontScale = 1.0;

const chat = document.getElementById('chat');
const emptyState = document.getElementById('emptyState');
const msgInput = document.getElementById('msgInput');
const sendBtn = document.getElementById('sendBtn');
const micBtn = document.getElementById('micBtn');
const hint = document.getElementById('hint');
const traceList = document.getElementById('trace');
const quickReplies = document.getElementById('quickReplies');
const crisisBanner = document.getElementById('crisisBanner');
const crisisLines = document.getElementById('crisisLines');
const backendStatus = document.getElementById('backendStatus');
const agentPills = document.getElementById('agentPills');
const profileSelect = document.getElementById('profileSelect');

/* --- Gateway health and downstream service status --- */
async function refreshStatus() {
  try {
    const services = await (await fetch(`${API_BASE}/services`)).json();
    backendStatus.textContent = "Connected to the orchestrator gateway at " + API_BASE;
    agentPills.innerHTML = services
      .map(s => `<div class="agent-pill ${s.status}"><span class="dot"></span>${s.name} ${s.status}</div>`)
      .join("");
  } catch {
    backendStatus.textContent =
      "The orchestrator is not reachable at " + API_BASE +
      ". Start it with: python run_all.py (or docker compose up --build).";
    agentPills.innerHTML = "";
  }
}
refreshStatus();
setInterval(refreshStatus, 15000);

/* --- Accessibility controls --- */
document.getElementById('btn-contrast').addEventListener('click', (e) => {
  highContrast = document.body.getAttribute('data-contrast') !== 'high';
  document.body.setAttribute('data-contrast', highContrast ? 'high' : 'normal');
  e.target.classList.toggle('active', highContrast);
  e.target.setAttribute('aria-pressed', String(highContrast));
});

document.getElementById('btn-size').addEventListener('click', (e) => {
  const large = document.body.getAttribute('data-size') !== 'large';
  document.body.setAttribute('data-size', large ? 'large' : 'normal');
  fontScale = large ? 1.4 : 1.0;
  e.target.classList.toggle('active', large);
  e.target.setAttribute('aria-pressed', String(large));
});

document.getElementById('btn-speak').addEventListener('click', (e) => {
  readAloud = !readAloud;
  e.target.classList.toggle('active', readAloud);
  e.target.setAttribute('aria-pressed', String(readAloud));
});

profileSelect.addEventListener('change', () => {
  if (profileSelect.value === 'visual' && !readAloud) {
    document.getElementById('btn-speak').click();
  }
});

/* --- Rendering --- */
function addMessage(who, text, data = {}) {
  if (emptyState) emptyState.remove();

  const wrap = document.createElement('div');
  wrap.className = 'msg ' + (who === 'You' ? 'user' : data.crisis_detected ? 'crisis' : 'bot');

  const label = document.createElement('p');
  label.className = 'who';
  label.textContent = who;
  wrap.appendChild(label);

  text.split('\n\n').forEach(part => {
    const p = document.createElement('p');
    p.textContent = part;
    wrap.appendChild(p);
  });

  const technique = data.coping_technique;
  if (technique && technique.steps) {
    const box = document.createElement('div');
    box.className = 'technique';
    box.innerHTML =
      `<p class="t-title">${technique.title}</p><ul>` +
      technique.steps.map(s => `<li>${s}</li>`).join('') +
      `</ul><div class="t-duration">${technique.duration || ''}</div>`;
    wrap.appendChild(box);
  }

  const chips = [];
  if (data.emotion_detected) chips.push(data.emotion_detected);
  if (data.risk_level) chips.push('risk: ' + data.risk_level);
  ((data.accessibility || {}).adaptations || []).forEach(a => chips.push(a));
  if (chips.length) {
    const row = document.createElement('div');
    row.className = 'tags';
    row.innerHTML = chips.map(c => `<span class="tag-chip">${c}</span>`).join('');
    wrap.appendChild(row);
  }

  chat.appendChild(wrap);
  chat.scrollTop = chat.scrollHeight;
}

function renderTrace(trace) {
  if (!trace || !trace.length) return;
  traceList.innerHTML = trace.map(step =>
    `<li><span class="service">${step.service}</span> — ${step.action}
      <span class="detail">${step.detail} · ${step.ms} ms</span></li>`
  ).join('');
}

function renderQuickReplies(options) {
  if (!options || !options.length) {
    quickReplies.hidden = true;
    quickReplies.innerHTML = '';
    return;
  }
  quickReplies.hidden = false;
  quickReplies.innerHTML = options.map(o => `<button type="button">${o}</button>`).join('');
}

function showCrisisBanner(helplines) {
  if (!helplines || !helplines.length) {
    crisisBanner.hidden = true;
    return;
  }
  crisisLines.innerHTML = helplines.map(h => `<li>${h}</li>`).join('');
  crisisBanner.hidden = false;
}

/* --- Speaking --- */
async function speak(text) {
  if (!readAloud) return;
  try {
    const data = await (await fetch(`${SPEECH_BASE}/speak`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text })
    })).json();
    if (data.audio_base64) {
      new Audio('data:audio/mp3;base64,' + data.audio_base64).play();
      return;
    }
  } catch { /* fall through to the browser voice */ }

  if ('speechSynthesis' in window) {
    speechSynthesis.cancel();
    speechSynthesis.speak(new SpeechSynthesisUtterance(text));
  }
}

/* --- Sending --- */
async function send(text) {
  addMessage('You', text);
  msgInput.value = '';
  sendBtn.disabled = true;

  try {
    const response = await fetch(`${API_BASE}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        message: text,
        session_id: sessionId,
        profile: profileSelect.value,
        high_contrast: highContrast,
        font_scale: fontScale
      })
    });
    if (!response.ok) throw new Error(await response.text());

    const data = await response.json();
    sessionId = data.session_id || sessionId;

    addMessage('MindBridge', data.reply || '', data);
    renderTrace(data.trace);
    renderQuickReplies((data.accessibility || {}).quick_replies);
    showCrisisBanner(data.helplines);

    if (data.crisis_detected || readAloud || (data.accessibility || {}).speak_aloud) {
      speak(data.reply || '');
    }
  } catch (error) {
    addMessage('MindBridge',
      'That reply could not be generated because a service is not running. ' +
      'Start everything with: python run_all.py');
    console.error(error);
  } finally {
    sendBtn.disabled = false;
    msgInput.focus();
  }
}

sendBtn.addEventListener('click', () => {
  const text = msgInput.value.trim();
  if (text) send(text);
});

msgInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') sendBtn.click();
});

document.addEventListener('click', (e) => {
  if (e.target.matches('.sample') || e.target.closest('.quick') === quickReplies && e.target.tagName === 'BUTTON') {
    send(e.target.textContent.trim());
  }
});

/* --- Voice input ---
   First choice: record audio and send it to speech-service for Whisper.
   Fallback: the browser's own Web Speech API when Whisper is not installed. */
let mediaRecorder = null;
let audioChunks = [];
let whisperAvailable = false;

fetch(`${SPEECH_BASE}/health`)
  .then(r => r.json())
  .then(d => { whisperAvailable = !!d.whisper_installed; })
  .catch(() => { whisperAvailable = false; });

async function recordWithWhisper() {
  if (mediaRecorder && mediaRecorder.state === 'recording') {
    mediaRecorder.stop();
    return;
  }
  const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
  mediaRecorder = new MediaRecorder(stream);
  audioChunks = [];

  mediaRecorder.ondataavailable = (e) => audioChunks.push(e.data);
  mediaRecorder.onstop = async () => {
    stream.getTracks().forEach(t => t.stop());
    micBtn.classList.remove('active');
    hint.textContent = 'Transcribing with Whisper…';

    const form = new FormData();
    form.append('file', new Blob(audioChunks, { type: 'audio/webm' }), 'recording.webm');
    try {
      const data = await (await fetch(`${SPEECH_BASE}/transcribe`, { method: 'POST', body: form })).json();
      if (data.text) {
        hint.textContent = 'Heard: ' + data.text;
        send(data.text);
      } else {
        hint.textContent = 'Nothing was picked up. Try again or type your message.';
      }
    } catch {
      hint.textContent = 'The speech service is not reachable. Type your message instead.';
    }
  };

  mediaRecorder.start();
  micBtn.classList.add('active');
  hint.textContent = 'Recording. Press Speak again to stop.';
}

function recordWithBrowser() {
  const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!Recognition) {
    hint.textContent = 'This browser has no speech recognition. Use Chrome or Edge, or type instead.';
    return;
  }
  const recognizer = new Recognition();
  recognizer.lang = 'en-IN';
  recognizer.interimResults = false;
  recognizer.onresult = (e) => {
    const text = e.results[0][0].transcript;
    hint.textContent = 'Heard: ' + text;
    send(text);
  };
  recognizer.onerror = () => { hint.textContent = 'Nothing was picked up. Try again or type.'; };
  recognizer.onend = () => micBtn.classList.remove('active');

  hint.textContent = 'Listening. Speak now.';
  micBtn.classList.add('active');
  recognizer.start();
}

micBtn.addEventListener('click', () => {
  if (whisperAvailable) recordWithWhisper().catch(() => recordWithBrowser());
  else recordWithBrowser();
});
