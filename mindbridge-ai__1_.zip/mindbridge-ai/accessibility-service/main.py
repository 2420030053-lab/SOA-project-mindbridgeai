"""
MindBridge AI - accessibility-service
Independent microservice: reshapes any agent's reply for the user's
accessibility profile and returns the TTS/ARIA metadata the frontend (or a
Flutter client) needs to render it accessibly.

Profiles:
  visual     - shorter text, read aloud, no sight-based wording
  hearing    - captions forced on, no sound-based wording
  speech     - reply answerable with yes or no
  motor      - quick-reply buttons instead of typing
  cognitive  - plain language, three sentences maximum
"""

import re
from typing import Literal

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="MindBridge AI - Accessibility Service", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

Profile = Literal["none", "visual", "hearing", "speech", "motor", "cognitive"]

# Words that assume a sense the user may not have.
VISUAL_WORDS = {"see": "notice", "look at": "think about", "watch": "follow"}
AUDIO_WORDS = {"listen to": "read", "hear": "read", "sounds like": "seems like"}


class AdaptRequest(BaseModel):
    text: str
    profile: Profile = "none"
    high_contrast: bool = False
    font_scale: float = 1.0
    screen_reader: bool = False


def split_sentences(text: str) -> list:
    return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s]


def simplify(text: str, max_sentences: int) -> str:
    kept = []
    for block in text.split("\n\n"):
        kept.extend(split_sentences(block))
    return " ".join(kept[:max_sentences])


def swap(text: str, table: dict) -> str:
    for source, target in table.items():
        text = re.sub(rf"\b{source}\b", target, text, flags=re.IGNORECASE)
    return text


@app.get("/health")
def health():
    return {"status": "healthy", "service": "accessibility-service"}


@app.post("/adapt")
def adapt(req: AdaptRequest):
    text = req.text
    adaptations = []
    speak_aloud = req.screen_reader
    captions = True
    reading_level = "standard"
    quick_replies = []

    if req.profile == "visual":
        text = swap(simplify(text, 3), VISUAL_WORDS)
        speak_aloud = True
        adaptations = ["read aloud automatically", "removed sight-based wording", "shortened for listening"]

    elif req.profile == "hearing":
        text = swap(text, AUDIO_WORDS)
        adaptations = ["captions always on", "removed sound-based wording"]

    elif req.profile == "speech":
        text = simplify(text, 3)
        if not text.rstrip().endswith("?"):
            text += " Would you like to keep going? Yes or no is fine."
        quick_replies = ["Yes", "No"]
        adaptations = ["reply answerable with yes or no", "shortened"]

    elif req.profile == "motor":
        text = simplify(text, 3) + " You can answer with one of the buttons below."
        quick_replies = ["Yes", "No", "Tell me more", "I'd like to stop here"]
        adaptations = ["quick-reply buttons offered", "typing not required"]

    elif req.profile == "cognitive":
        text = re.sub(r"\s+", " ", simplify(text, 3))
        reading_level = "plain"
        adaptations = ["plain language", "one idea per sentence", "three sentences max"]

    else:
        adaptations = ["no adaptation needed"]

    sections = [s.strip() for s in text.split("\n\n") if s.strip()] or [text.strip()]

    return {
        "adapted_text": text.strip(),
        "semantic_sections": sections,
        "profile": req.profile,
        "adaptations": adaptations,
        "reading_level": reading_level,
        "speak_aloud": speak_aloud,
        "captions": captions,
        "quick_replies": quick_replies,
        "tts_recommended_rate_wpm": 130 if speak_aloud else 150,
        "font_scale": max(0.8, min(req.font_scale, 2.0)),
        "high_contrast": req.high_contrast,
        "aria_live_mode": "assertive" if "helpline" in text.lower() else "polite",
    }
